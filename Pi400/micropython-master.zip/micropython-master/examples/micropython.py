# micropython module placeholder for CPython

# Dummy function decorators


def nodecor(x):
    return x


bytecode = native = viper = nodecor
