.. _rp2_general:

General information about the RP2xxx port
=========================================

The rp2 port supports boards powered by the Raspberry Pi Foundation's RP2xxx
family of microcontrollers, most notably the Raspberry Pi Pico that employs
the RP2040.

Technical specifications and SoC datasheets
-------------------------------------------

Datasheets!

Short summary of tech specs!

Description of general structure of the port (it's built on top of the APIs
provided by the Raspberry Pi SDK).
